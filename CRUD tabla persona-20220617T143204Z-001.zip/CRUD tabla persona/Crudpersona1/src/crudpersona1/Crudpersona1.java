package crudpersona1;

/**
 *
 * @author Maruja
 */
public class Crudpersona1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
